/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Question_4;

import org.apache.commons.lang3.StringUtils;
/**
 *
 * @author bbush
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            boolean parenthesesBalanceIsZero = check(args[0]);
            if(!parenthesesBalanceIsZero){
                System.err.println("The passed LISP program doesn't contain an equal number of opening and closing parentheses!");
            }else{
                System.out.println("The passed LISP program contains an equal number of opening and closing parentheses.");
            }
        } catch (Exception e){
            try {System.err.println(e.toString());} catch(Exception e1){}
            try {e.printStackTrace();} catch(Exception e2){}
        }
    }
    
    public static boolean check(String lispProgram){
        return (StringUtils.countMatches(lispProgram, '(') - StringUtils.countMatches(lispProgram, ')')) == 0;
    }
}
