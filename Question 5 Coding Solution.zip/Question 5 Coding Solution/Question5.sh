#!/bin/bash

#Usage: Question5.sh "enrollment_file.csv"

#Grab the insurance companies from the file.
#1) Assume the first line is a header containing field names and skip it.
#2) Assume insurance companies are in the fourth column and extract them. 
#3) Replace spaces in the company name with "_".  Otherwise, we'll get back
#   a list of the individual words in the company names.
#4) Remove carriage returns (in case the input csv is coming from a Windows
#   environment)
#5) Sort the company names.  This is necessary for the uniq command to work
#6) Trim down the list of company names to unique values.
for insurance_company in \
	$(sed 1d $1 \
       	| cut --delimiter=',' --fields=4 \
	| sed 's/ /_/g' \
	| sed 's/\r//g' \
	| sort \
	| uniq)
do
	# Build the name of the output file to be created for this specific
        # insurance company.
	insurance_company_csv=$insurance_company".csv"

	# Copy the header from the input file to the first line of the enrollment
	# being created for this specific insurance company.	
	head --lines=1 $1 > $insurance_company_csv
	
	#Put the spaces back in the company name.
	insurance_company="$(echo $insurance_company | sed 's/_/ /g')"

	#Build gawk program used in the first step of the next operation
	gawk_program='{if($4=="'$insurance_company'")print$0}'
	
	#1) Grab all records from the input file that contain the current company.
	#2) Assuming the User Id is in the first column and the Version is in the
	#   third column, movie the Version to the second column.  This is necessary
	#   to sort on User Id and Version.
	#3) Sort the records by Version (descending) then by User Id (descending)
	#4) Put the columns back in their original order.
	#5) Grab the first record for each User Id.  After sorting, this should be
        #   the record containing the highest Version for said User Id.
	#6) Assuming the second column contains the full name and the last name is
	#   listed last, separate the last name into its own column.
	#7) Sort the records by last name (ascending) then first name (ascending)
	#8) Combine the name columns back into a single column.
	#9) Output the record to enrollment file being created for this specific company.
     	gawk --field-separator=',' < $1 "$gawk_program" \
		| gawk --field-separator=',' '{print $1 "," $3 "," $2 "," $4}' \
		| sort --field-separator=',' --key=1,1 --key=2,2 --version-sort --reverse \
		| gawk --field-separator=',' '{print $1 "," $3 "," $2 "," $4}' \
		| gawk --field-separator=',' '!seen[$1]++' \
		| sed 's/\([^,]*,\)\(.* \|\)\([^ ]*\|\)\(,[^,]*\)/\1\2,\3\4/' \
		| sort --field-separator=',' --key=3,3 --key=2,2 --key=1,1 \
		| sed 's/\([^,]*,[^,]*\),\(.*\)/\1\2/' \
	     	>> $insurance_company_csv
done

#Return a status code indicating a successful execution
exit 0
